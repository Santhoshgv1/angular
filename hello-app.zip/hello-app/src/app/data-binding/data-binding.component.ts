import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {
uname:string='hello';
city:string='banglore';
name='LTE';
year='2010';

source:any="assets/one.jpg";
high:number=400;
wid:number=500;
src='assets/lion.jpg';
enable:boolean=false;

val:number=0;

tname:string=''
  constructor() { }

  ngOnInit(): void {
  }

  change(){
    this.enable=!this.enable;
  }

  getDetails()
  {
    return `Hi this is ${this.name} and city is ${this.city}`;
  }

  demo(v:number,v2:number)
  {
    this.val=v+v2;
  }


}
