import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  msg:string="";
  prop:string="";

  constructor(){ }
  ngOnInit(): void {
  }

  login(value:any)
  {
      if(value.email == "santhoshgv0@gmail.com" && value.password == 123456)
      {
        this.msg='successfully logged in';
        this.prop='green';
      }
      else
      {
        this.msg='login not sussccefull';
        this.prop='red';
      }
  }

}
