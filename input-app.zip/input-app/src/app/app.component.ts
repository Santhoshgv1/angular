import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  
  fruits="grapes";

  newFruits=['apple','grape','banana'];
  
  addFruits(value:any)
  {
      this.newFruits.push(value);
  }



}
