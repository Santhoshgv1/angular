import { Component, DoCheck, Input, OnInit} from '@angular/core';

@Component({
  selector: 'life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit ,DoCheck{

  constructor() { 
    console.log('Component is initilized...')
  }

  ngOnInit(): void {
    console.log('init methode is called.....');
  }

  ngDoCheck(): void {
    console.log('ngDocheck is called....');
  }

}
